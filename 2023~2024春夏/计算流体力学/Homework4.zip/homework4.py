import numpy as np
import matplotlib.pyplot as plt

# Constants
XMAX = 300
YMAX = 100
PI = 2.*np.arcsin(1.)

# Variables
IMAX = 101  # No. of nodes in ksi direction i.e. (IMAX-1 Div)
JMAX = 26  # Initial No. of nodes in eta direction i.e. (JMAX-1 Div)
thickness = 0.12
x = np.zeros((XMAX, YMAX))
y = np.zeros((XMAX, YMAX))
P = np.zeros((XMAX, YMAX))
Q = np.zeros((XMAX, YMAX))

# Initialize x and y
x.fill(0.001)
y.fill(0.001)

# Lower half Boundary Points
r = 0.8  # Ratio in ksi direction in the cut
h = 3.*(1.-r)/(1.-pow(r,(IMAX-1)/5.))  # smallest h in ksi direction in the cut
dh = 0.
for i in range((IMAX-1)//2 + 1):
    if i < (IMAX-1)//5:
        x[i][0] = 4.-dh
        y[i][0] = 0.
        x[i][JMAX-1] = 4.-dh
        y[i][JMAX-1] = -2.
        dh += h*pow(r, float(i))
    elif i < 7*(IMAX-1)//20:
        x[i][0] = 0.5+0.5*np.cos(0.5*PI*(i-(IMAX-1)/5)/(7*(IMAX-1)/20-(IMAX-1)/5))
        y[i][0] = -5.*thickness*(0.1781*pow(x[i][0],0.5)-0.0756*x[i][0]-0.2122*pow(x[i][0],2.)+0.1705*pow(x[i][0],3.)-0.0609*pow(x[i][0],4.))
        x[i][JMAX-1] = 1.-3.*pow(np.sin((i-(IMAX-1)/5)*PI/(2*((IMAX-1)/2-(IMAX-1)/5))),1.3)
        y[i][JMAX-1] = -2.*(np.cos((i-(IMAX-1)/5)*PI/(2*((IMAX-1)/2-(IMAX-1)/5))))
    else:
        x[i][0] = 0.5-0.5*np.sin(0.5*PI*(i-(7*(IMAX-1)/20))/(7*(IMAX-1)/20-(IMAX-1)/5))
        y[i][0] = -5.*thickness*(0.1781*pow(x[i][0],0.5)-0.0756*x[i][0]-0.2122*pow(x[i][0],2.)+0.1705*pow(x[i][0],3.)-0.0609*pow(x[i][0],4.))
        x[i][JMAX-1] = 1.-3.*pow(np.sin((i-(IMAX-1)/5)*PI/(2*((IMAX-1)/2-(IMAX-1)/5))),1.3)
        y[i][JMAX-1] = -2.*(np.cos((i-(IMAX-1)/5)*PI/(2*((IMAX-1)/2-(IMAX-1)/5))))

dxi = 1./(IMAX-1)
deta = 1./(JMAX-1)

# Upper half of the Boundary Points
for i in range((IMAX-1)//2+1, IMAX):
    x[i][0] = x[(IMAX-1)-i][0]
    y[i][0] = -y[(IMAX-1)-i][0]
    x[i][JMAX-1] = x[(IMAX-1)-i][JMAX-1]
    y[i][JMAX-1] = -y[(IMAX-1)-i][JMAX-1]

# Boundary Points at outflow
r = 1.2  # Ratio in eta direction at the outflow
h = 2.*(1.-r)/(1.-pow(r,(JMAX-1)))  # smallest h in eta direction at the outflow
dh = 0.
for j in range(JMAX):
    x[0][j] = 4.
    y[0][j] = -dh
    x[IMAX-1][j] = 4.
    y[IMAX-1][j] = dh
    dh += h*pow(r, float(j))

# Trans-Finite interpolation for inner points
for j in range(1, JMAX-1):
    for i in range(1, IMAX-1):
        x[i][j] = ((i)/(IMAX-1))*x[IMAX-1][j] + (((IMAX-1)-i)/ (IMAX-1))*x[0][j] + ((j)/(JMAX-1))*x[i][JMAX-1] + (((JMAX-1)-j)/(JMAX-1))*x[i][0] - ((i)/(IMAX-1))*((j)/(JMAX-1))*x[IMAX-1][JMAX-1] - ((i)/(IMAX-1))*(((JMAX-1)-j)/(JMAX-1))*x[IMAX-1][0] - (((IMAX-1)-i)/ (IMAX-1))*((j)/(JMAX-1))*x[0][JMAX-1] - (((IMAX-1)-i)/(IMAX-1))*(((JMAX-1)-j)/(JMAX-1))*x[0][0]
        y[i][j] = ((i)/(IMAX-1))*y[IMAX-1][j] + (((IMAX-1)-i)/(IMAX-1))*y[0][j] + ((j)/(JMAX-1))*y[i][JMAX-1] + (((JMAX-1)-j)/(JMAX-1))*y[i][0] - ((i)/(IMAX-1))*((j)/(JMAX-1))*y[IMAX-1][JMAX-1] - ((i)/(IMAX-1))*(((JMAX-1)-j)/(JMAX-1))*y[IMAX-1][0] - (((IMAX-1)-i)/ (IMAX-1))*((j)/(JMAX-1))*y[0][JMAX-1] - (((IMAX-1)-i)/(IMAX-1))*(((JMAX-1)-j)/(JMAX-1))*y[0][0]

# Plot the grid
#plt.figure(figsize=(10, 10))
#plt.scatter(x, y, s=1)
#plt.show()

# Solving Laplace equation using Gauss-Siedel algorithm
omega = 0.3
residual = 1.
alf = 0.
beta = 0.
gam = 0.
xtemp = 0.
ytemp = 0.
ITR = 0
a = 0.1
aa = 225.
c = 3.6
cc = 8.5
# Continue solving Laplace equation using Gauss-Siedel algorithm
while residual > 0.000001:  # Convergence Criterion
    residual = 0.
    ITR += 1
    for j in range(1, JMAX-1):
        for i in range(1, IMAX-1):
            xeta = (x[i][j+1]-x[i][j-1])/(2.*deta)
            yeta = (y[i][j+1]-y[i][j-1])/(2.*deta)
            xxi = (x[i+1][j]-x[i-1][j])/(2.*dxi)
            yxi = (y[i+1][j]-y[i-1][j])/(2.*dxi)
            J = xxi*yeta - xeta*yxi
            alf = (xeta*xeta+yeta*yeta)
            beta = (xxi*xeta+yxi*yeta)
            gam = (xxi*xxi+yxi*yxi)
            if abs((i)/(IMAX-1)-0.5) == 0.:
                PP = 0.
            else:
                PP = -a*((i)/(IMAX-1)-0.5)/(abs((i)/(IMAX-1)-0.5))*np.exp(-c*abs((i)/(IMAX-1)-0.5))
            if abs((j)/(JMAX-1)-0.0) == 0.:
                QQ = 0.
            else:
                QQ = -aa*((j)/(JMAX-1)-0.0)/(abs((j)/(JMAX-1)-0.0))*np.exp(-cc*abs((j)/(JMAX-1)-0.0))
            xtemp = pow(dxi*deta,2.)/(2.*(alf*deta*deta+gam*dxi*dxi))*(alf/(dxi*dxi)*(x[i+1][j]+x[i-1][j]) + gam/(deta*deta)*(x[i][j+1]+x[i][j-1]) - beta/(2.*dxi*deta)*(x[i+1][j+1]+x[i-1][j-1]-x[i-1][j+1]-x[i+1][j-1]) + (J*J)*(xxi*PP+xeta*QQ))
            ytemp = pow(dxi*deta,2.)/(2.*(alf*deta*deta+gam*dxi*dxi))*(alf/(dxi*dxi)*(y[i+1][j]+y[i-1][j]) + gam/(deta*deta)*(y[i][j+1]+y[i][j-1]) - beta/(2.*dxi*deta)*(y[i+1][j+1]+y[i-1][j-1]-y[i-1][j+1]-y[i+1][j-1]) + (J*J)*(yxi*PP+yeta*QQ))
            residual = residual + pow((x[i][j]-xtemp),2.) + pow((y[i][j]-ytemp),2.)
            xtemp = omega*xtemp + (1.-omega)*x[i][j]
            ytemp = omega*ytemp + (1.-omega)*y[i][j]
            x[i][j] = xtemp
            y[i][j] = ytemp
    residual = np.sqrt(residual)

# Plot the grid after solving Laplace equation
plt.figure(figsize=(10, 10))
for i in range(1,IMAX):
    plt.plot(x[i, 0:JMAX-1], y[i, 0:JMAX-1], color='k')
for j in range(JMAX-1):
    plt.plot(x[1:IMAX-1, j], y[1:IMAX-1, j], color='k')
plt.show()
