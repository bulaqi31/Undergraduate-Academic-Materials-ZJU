%   参数设定

H = 1;
L = 50;
rho = 1;
miu = 1;
Nx = 100;
Ny = 10;
delta_x = L / Nx;
delta_y = H / Ny;
delta_t = 0.001;
alpha = 0.1;
p1 = 8;
p2 = 0;

%   初始条件和边界条件

u = zeros(Nx+2,Ny+1);
v = zeros(Nx+3,Ny+2);
p_star = zeros(Nx+1,Ny+1);
p_prime = zeros(Nx+1,Ny+1);
p_star(1,:) = p1;
p_star(Nx+1,:) = p2;
    
%   压力修正方法

for K = 1 : 10000
    
    rho_u = rho * u;
    rho_v = rho * v;

    % 算下一个时刻
    v_ = zeros(Nx+2,Ny+1);
    v_([2:Nx+1],[3:Ny+1]) = 0.5 * ( v([2:Nx+1],[3:Ny+1]) +  v([3:Nx+2],[3:Ny+1]) );
    v__ = zeros(Nx+2,Ny+1);
    v__([2:Nx+1],[1:Ny-1]) = 0.5 * ( v([2:Nx+1],[2:Ny]) + v([3:Nx+2],[2:Ny]) );
    A = -( ( rho * ( u([3:Nx+2],[2:Ny]) ).^2 - rho * ( u([1:Nx],[2:Ny]) ).^2 ) / (2*delta_x)...
        + ( rho * u([2:Nx+1],[3:Ny+1]) .* v_([2:Nx+1],[3:Ny+1]) ...
        - rho * u([2:Nx+1],[1:Ny-1]) .* v__([2:Nx+1],[1:Ny-1]) ) / (2*delta_y) ) ...
        + miu * ( ( u([3:Nx+2],[2:Ny]) - 2 * u([2:Nx+1],[2:Ny]) + u([1:Nx],[2:Ny]) ) / (delta_x^2) ...
        + ( u([2:Nx+1],[3:Ny+1]) - 2 * u([2:Nx+1],[2:Ny]) + u([2:Nx+1],[1:Ny-1]) ) / (delta_y^2) );
    rho_u([2:Nx+1],[2:Ny]) = rho_u([2:Nx+1],[2:Ny]) + A * delta_t ...
        - delta_t / delta_x * ( p_star([2:Nx+1],[2:Ny]) - p_star([1:Nx],[2:Ny]) );
    u([2:Nx+1],[2:Ny]) = rho_u([2:Nx+1],[2:Ny]) / rho;
    
    u_ = zeros(Nx+3,Ny+2);
    u_([3:Nx+3],[2:Ny+1]) = 0.5 * ( u([2:Nx+2],[2:Ny+1]) + u([2:Nx+2],[1:Ny]) );
    u__ = zeros(Nx+3,Ny+2);
    u__([1:Nx+1],[2:Ny+1]) = 0.5 * ( u([1:Nx+1],[2:Ny+1]) + u([1:Nx+1],[1:Ny]) );
    B = -( ( rho * v([3:Nx+3],[2:Ny+1]) .* u_([3:Nx+3],[2:Ny+1]) - rho * v([1:Nx+1],[2:Ny+1]) .* u__([1:Nx+1],[2:Ny+1]) ) / (2*delta_x) ...
        + ( rho * ( v([2:Nx+2],[3:Ny+2]) ).^2  - rho * ( v([2:Nx+2],[1:Ny]) ).^2 ) / (2*delta_y) )...
        + miu * ( ( v([3:Nx+3],[2:Ny+1]) - 2 * v([2:Nx+2],[2:Ny+1]) + v([1:Nx+1],[2:Ny+1]) ) / (delta_x^2) ...
        + ( v([2:Nx+2],[3:Ny+2]) - 2 * v([2:Nx+2],[2:Ny+1]) + v([2:Nx+2],[1:Ny]) ) / (delta_y^2) );
    rho_v([2:Nx+2],[2:Ny+1]) = rho_v([2:Nx+2],[2:Ny+1]) + B * delta_t ...
        - delta_t / delta_y * ( p_star([1:Nx+1],[2:Ny+1]) - p_star([1:Nx+1],[1:Ny]) );
    v([2:Nx+2],[2:Ny+1]) = rho_v([2:Nx+2],[2:Ny+1]) / rho;
    
    %边界
    
    p_star(:,1) = p_star(:,2);
    p_star(:,Ny+1) = p_star(:,Ny);
    u(1,:) = u(2,:);        %   入口处水平速度外推
    u(Nx+2,:) = u(Nx+1,:);  %   出口处水平速度外推
    v(Nx+3,:) = v(Nx+2,:);  %   出口处垂直速度外推
    
    %修正值
    
    a = 2 * ( delta_t / delta_x^2 + delta_t / delta_y^2 );
    b = -delta_t / delta_x^2;
    c = -delta_t / delta_y^2;
    d = ( rho_u([3:Nx+1],[2:Ny]) - rho_u([2:Nx],[2:Ny]) ) / delta_x ...
        + ( rho_v([3:Nx+1],[3:Ny+1]) - rho_v([3:Nx+1],[2:Ny]) ) / delta_y;
    
    %松弛法
    
    p_prime1 = zeros(Nx+1,Ny+1);
    p_prime2 = zeros(Nx+1,Ny+1);
    p_prime1([2:Nx],[2:Ny]) = p_prime([2:Nx],[2:Ny]);
    p_prime([2:Nx],[2:Ny]) = -1/a * ( b * p_prime([3:Nx+1],[2:Ny]) + b * p_prime([1:Nx-1],[2:Ny]) ...
            + c * p_prime([2:Nx],[3:Ny+1]) + c * p_prime([2:Nx],[1:Ny-1]) + d );
    p_prime2([2:Nx],[2:Ny]) = p_prime([2:Nx],[2:Ny]);
    e = sum(abs(p_prime2 - p_prime1),'all');
    k = 1;
    
    while e>1e-5
        p_prime1 = p_prime2;
        p_prime([2:Nx],[2:Ny]) = -1/a * ( b * p_prime([3:Nx+1],[2:Ny]) + b * p_prime([1:Nx-1],[2:Ny]) ...
            + c * p_prime([2:Nx],[3:Ny+1]) + c * p_prime([2:Nx],[1:Ny-1]) + d );
        p_prime2([2:Nx],[2:Ny]) = p_prime([2:Nx],[2:Ny]);
        e = sum(abs(p_prime2 - p_prime1),'all');
        k = k + 1;
    end
    
    %压力
    
    p_star([2:Nx],[2:Ny]) = p_star([2:Nx],[2:Ny]) + alpha * p_prime([2:Nx],[2:Ny]);
    
end


y = 0 : delta_y : H;
u_ex = (p1-p2)/(2*miu*L) * y .* (H-y);
u_exact = zeros(Nx+2,Ny+1);
for i = 1 : Nx+2
   u_exact(i,:) = u_ex; 
end

figure(1)

% subplot(2,2,1)
pcolor(u');
xlabel('x')
ylabel('y')
title('速度场',FontSize=20);
colorbar
shading interp
colormap('summer')

figure(2)
pcolor(p_star');
xlabel('x')
ylabel('y')
title('压力场',FontSize=20);
colorbar
shading interp
colormap('spring')
