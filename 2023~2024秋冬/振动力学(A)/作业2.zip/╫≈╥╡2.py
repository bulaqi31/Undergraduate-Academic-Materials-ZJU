import numpy as np
import matplotlib.pyplot as plt
from math import atan,sqrt,sin,cos,exp,pi
zeta = 0.05
err = 0.000001
num = 1000
def megnitude(t,t1):
    if t>t1:
        y = (exp(-zeta*2*pi*(t-t1))*cos(2*pi*(t-t1)) - exp(-zeta*2*pi*t)*cos(2*pi*t))/sqrt(1-zeta*zeta)
    else:
        y = 1 - exp(-zeta*2*pi*t)*cos(2*pi*t)/sqrt(1-zeta*zeta)
    return y

def dx(t,t1):#导函数
    #导函数只是为了二分法求极点
    #t<t1的情况下，极点可以直接算出，故只给出t>t1情况的导函数
    result = zeta*cos(2*pi*t)-exp(2*pi*t1*zeta)*zeta*cos(2*pi*(t-t1)) + sin(2*pi*t) - exp(2*pi*t1*zeta)*sin(2*pi*(t-t1))
    return result
def root(t1):
    '''minn,maxx = 0,t1
    middle = (minn+maxx)/2
    while(maxx-minn) > err:
        middle = (minn+maxx)/2
        if abs(dx(middle,t1))<=err:
            break 
        else:
            if dx(middle,t1)<-err:
                maxx = middle
            if dx(middle,t1)>err:
                minn = middle
    '''
    xxx = (atan(-zeta)+pi)/pi/2 #t<t1的极点

    minn,maxx = t1,1000 #二分法
    middle = (minn+maxx)/2
    while(maxx-minn) > err:
        middle = (minn+maxx)/2
        if abs(dx(middle,t1))<=err:
            break
        else:
            if dx(middle,t1)<-err:
                maxx = middle
            if dx(middle,t1)>err:
                minn = middle
    yyy = middle
    return max(megnitude(xxx,t1),megnitude(yyy,t1))  #两个分段的最大值中的最大值，才是整体最大值
# 生成 x 值
x = np.linspace(0, 3, num)  # 在指定范围内生成一组 t1 值
y = np.linspace(0, 0, num)

for i in range(num):
    kk = root(x[i])
    y[i] = kk
# 计算对应的 y 值


# 绘制函数图形
plt.plot(x, y)

# 设置标题和坐标轴标签
plt.title("\zeta = {}".format(zeta))
plt.xlabel("t1/T")
plt.ylabel("x_m/x_s")

# 显示图形
plt.show()