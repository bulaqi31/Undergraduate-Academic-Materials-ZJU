import numpy as np
import matplotlib.pyplot as plt

def doit(a):
    i=0
    for j in range(1,19):       #  找到在哪个区间
        if a<x[j]:
            i=j
            break
        # 做计算
    ans=M[i-1]*(x[i]-a)**3/6/h[i]\
        +M[i]*(a-x[i-1])**3/6/h[i]\
        +(y[i-1]-M[i-1]*h[i]**2/6)*(x[i]-a)/h[i]\
        +(y[i]-M[i]*h[i]**2/6)*(a-x[i-1])/h[i]
    print(f'y({a}) = {ans[0]}')
    return ans

x=np.array(
    [0.52, 3.1, 8.0, 17.95, 28.65, 39.62, 50.65,
     78, 104.6, 156.6, 208.6, 260.7, 312.5,
     364.4, 416.3, 468, 494, 507, 520]
)

y=np.array(
    [5.28794, 9.4, 13.84, 20.2, 24.9, 28.44, 31.1,
     35, 36.5, 36.6, 34.6, 31.0, 26.34,
     20.9, 14.8, 7.8, 3.7, 1.5, 0.2]
)

plt.plot(x,y)
h=np.zeros(30)
u=np.zeros(30)
l=np.zeros(30)
g=np.zeros(19)
for i in range(1,19):
    h[i]=x[i]-x[i-1]

for i in range(1,18):
    u[i]=h[i]/(h[i]+h[i+1])

for i in range(1,18):
    l[i]=1-u[i]

for i in range(1,18):
    g[i]=6/(h[i]+h[i+1])*((y[i+1]-y[i])/h[i+1]-(y[i]-y[i-1])/h[i])
g[0]=6/h[1]*((y[1]-y[0])/h[1]-1.86548)
g[18]=6/h[18]*(-0.046115-(y[18]-y[17])/h[18])
g=g.reshape(19,1)

A=np.zeros((19,19))
A[0][0],A[0][1]=2,1
A[18][17],A[18][18]=1,2

for i in range(1,18):
    A[i][i-1],A[i][i],A[i][i+1]=u[i],2,l[i]

M=np.zeros((19,1))
M=np.linalg.inv(A) @ g

# 以上解出M
xx=[2,4,6,12,16,30,60,110,180,280,400,515]
yy=[2,4,6,12,16,30,60,110,180,280,400,515]
for i in range(12):
    yy[i]=doit(xx[i])
    
plt.plot(xx,yy,'ro')
plt.show()
