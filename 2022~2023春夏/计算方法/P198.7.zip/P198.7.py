import numpy as np
A=np.array(
    [[4,-1,0,-1,0,0],
     [-1,4,-1,0,-1,0],
     [0,-1,4,-1,0,-1],
     [-1,0,-1,4,-1,0],
     [0,-1,0,-1,4,-1],
     [0,0,-1,0,-1,4]
    ]
)

b=np.array([0,5,-2,5,-2,6])
b=b.reshape(6,1)

D=4*np.eye(6)

L=np.array(
    [[0,0,0,0,0,0],
     [1,0,0,0,0,0],
     [0,1,0,0,0,0],
     [1,0,1,0,0,0],
     [0,1,0,1,0,0],
     [0,0,1,0,1,0]
    ]
)

U=(A-D+L)*-1

D_1=np.linalg.inv(D)

# 以上是对数据的预处理
#---------雅克比----------
k=0
X=np.ones(6).reshape(6,1)
B_J = D_1 @ (L+U)
f_J = D_1 @ b
ans = np.zeros_like(X)
while 1:
    k+=1
    ans = B_J @ X + f_J
    if abs(np.linalg.norm(ans-X))<=0.0001:
        break
    X=ans
print("雅可比迭代法的解是：")
print(ans)
print(f'迭代次数：{k}')

# 高斯-赛尔德迭代法
k=0
X=np.ones(6).reshape(6,1)
B_G = np.linalg.inv(D-L) @ U
f_G = np.linalg.inv(D-L) @ b
ans = np.zeros_like(X)
while 1:
    k+=1
    ans = B_G @ X + f_G
    if abs(np.linalg.norm(ans-X))<=0.0001:
        break
    X=ans
print("高斯-赛尔德迭代法的解是：")
print(ans)
print(f'迭代次数：{k}')

#SOR方法

def SOR(w):
    k=0
    X=np.ones(6).reshape(6,1)
    B_w = np.linalg.inv(D-w*L) @ ((1-w)*D+w*U)
    f_w = w*np.linalg.inv(D-w*L) @ b
    ans = np.zeros_like(X)
    while 1:
        k+=1
        ans = B_w @ X + f_w
        if abs(np.linalg.norm(ans-X))<=0.0001:
            break
        X=ans
    print(f'SOR(w={w})迭代法的解是：')
    print(ans)
    print(f'迭代次数：{k}')
SOR(1.334)
SOR(1.95)
SOR(0.95)