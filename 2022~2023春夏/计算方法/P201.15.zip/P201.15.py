from math import *
T = []

for i in range(4):  # 创建一个二维数组记录
    row = [0]*10
    T.append(row)

def f(theta):       # 积分式里面的函数
    return sqrt(1-3/4*sin(theta)**2)

a,b = 0,pi/2

T[0][0] = (b-a)/2*(f(a)+f(b))

for i in range(1,4):
    T[0][i] = T[0][i-1]/2
    for j in range(1,2**(i-1)+1):
        T[0][i] += (b-a)/pow(2,i) * f(a+(2*j-1)*(b-a)/pow(2,i))

for i in range(1,4):
    for j in range(i,4):
        T[i][j] = (pow(4,i)*T[i-1][j]-T[i-1][j-1])/(pow(4,i)-1)
# 以上完成三次二分

l = 3
diff = 1
while diff > 0.0001:
    l += 1
    T[0][l] = T[0][l-1] / 2
    for j in range(1,2**(l-1)+1):
        T[0][l] += (b-a)/(pow(2,l)) * f(a+(2*j-1)*(b-a)/pow(2,l))
    for i in range(1,4):
        T[i][l] = (pow(4,i)*T[i-1][l]-T[i-1][l-1])/(pow(4,i)-1)
    diff = 80*abs(T[3][l] - T[3][l-1])

length = T[3][l]*80
print(f'{l}次二分')
print(f'得到周长为{length}')