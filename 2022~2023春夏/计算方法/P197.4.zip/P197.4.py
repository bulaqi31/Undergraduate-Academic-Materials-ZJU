import numpy as np

# 定义矩阵A和列向量b
A = np.array([[1.1348, 3.8326, 1.1651, 3.4017],
              [0.5301, 1.7875, 2.5330, 1.5435],
              [3.4129, 4.9317, 8.7643, 1.3142],
              [1.2371, 4.9998, 10.6721, 0.0147]])

b = np.array([[9.5342], [6.3941], [18.4231], [16.9237]])

# 顺序消元求解
for i in range(3):
    for j in range(i+1,4):
        factor=A[j,i]/A[i,i]
        A[j,:] -= factor * A[i,:]
        b[j] -= factor * b[i]

# 回带求解
x=np.zeros(4)
x[3]=b[3]/A[3,3]
for i in range(2,-1,-1):
    x[i] = (b[i] - A[i,i+1:] @ x[i+1:])/A[i,i]

# 输出结果
print("使用顺序消元法解为：")
for i in range(4):
    print(f"x{i+1}={x[i]:5f}")

print()
print()
print()

# 使用列主元消元法

A = np.array([[1.1348, 3.8326, 1.1651, 3.4017],
              [0.5301, 1.7875, 2.5330, 1.5435],
              [3.4129, 4.9317, 8.7643, 1.3142],
              [1.2371, 4.9998, 10.6721, 0.0147]])

b = np.array([[9.5342], [6.3941], [18.4231], [16.9237]])
# 列主元消元求解
for i in range(3):
    max_row=np.argmax(np.abs(A[i:,i]))+i
    A[[i,max_row],:]=A[[max_row,i],:]
    b[[i,max_row],:]=b[[max_row,i],:]
    for j in range(i+1,4):
        factor = A[j,i] / A[i,i]
        A[j,:] -= A[i,:] * factor
        b[j] -= b[i] * factor

#代回求解

x[3]=b[3]/A[3,3]
for i in range(2,-1,-1):
    x[i] = (b[i] - A[i,i+1:] @ x[i+1:])/A[i,i]

# 输出结果
print("使用列主元消元法解为：")
for i in range(4):
    print(f"x{i+1}={x[i]:5f}")