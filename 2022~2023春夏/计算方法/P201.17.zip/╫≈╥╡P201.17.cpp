#include<cstdio>
#include<cmath>
using namespace std;

double f(double x,double y)
{
	return 2.0/3.0*x/y/y;
}
 
double Exact(double x)
{
	return pow(1+x*x,1.0/3.0);
}

void Ext()
{
	printf("\n��ȷ�⣺\n");
	double i = 0;
	while(i<=1)
	{
		printf("y(%.1lf) = %.8lf\n",i,Exact(i));
		i += 0.1;
	}
}

void Eular()
{
	printf("\nŷ������:\n");
	
	double x = 0,y = 1.0;
	while(x<=1)
	{
		printf("y(%.1lf) = %lf\n",x,y);
		y = y + 0.1*f(x,y);
		x += 0.1;
	}
}

void Modified()
{
	printf("\n�Ľ�ŷ������:\n");
	
	double x = 0,y = 1.0;
	while(x<=1)
	{
		printf("y(%.1lf) = %lf\n",x,y);
		y = y + 0.05*(f(x,y) + f(x+0.1, y + 0.1*f(x,y)));
		x += 0.1;
	}
}

void R_K()
{
	printf("\n����R_K��:\n");
	
	double x = 0,y = 1.0;
	while(x<=1)
	{
		printf("y(%.1lf) = %lf\n",x,y);
		double k1 = f(x,y);
		double k2 = f(x+0.05,y+0.05*k1);
		double k3 = f(x+0.05,y+0.05*k2);
		double k4 = f(x+0.1,y+0.1*k3);
		y = y + 0.1/6.0*(k1+2*k2+2*k3+k4);
		x += 0.1;
	}
}

int main()
{
	Ext();
	Eular();
	Modified();
	R_K();
	return 0;
}
