a = 5; b = 4; na = 40; nb = 32;

T = zeros(nb,na);
T(end,:) = 80;

x = linspace(0, a, na);
y = linspace(0, b, nb);
[X, Y] = meshgrid(x, y);

diff = 1; % difference
tolerance = 1e-9; % accuracy

while diff > tolerance 
    T_old = T; % last time
    for i = 2:nb-1 % direction y
        for j = 2:na-1 % direction x
            % now
            T(i,j) = (T(i-1,j) + T(i+1,j) + T(i,j-1) + T(i,j+1)) / 4;
        end
    end
    diff = max(max(abs(T - T_old))); % difference
end

mesh(X,Y,T)
xlabel('x (m)'); ylabel('y (m)'); zlabel('T (^oC)');
figure
surf(X,Y,T)
xlabel('x (m)'); ylabel('y (m)'); zlabel('T (^oC)');
figure
surface(X,Y,T)
xlabel('x (m)'); ylabel('y (m)'); zlabel('T (^oC)');
