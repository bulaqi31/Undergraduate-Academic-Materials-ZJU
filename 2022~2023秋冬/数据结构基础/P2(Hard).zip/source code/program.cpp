#include<stdio.h>
#include<math.h>
#define pi 3.141592653589
#define L 0.2

double ax[105],ay[105],bx[105],by[105];
int voting[105][105],add[105][105];
int chosenline[105];
int n,m,tot;

struct tree
{
	int A,B;
}tt[105];

double length1(int a,int b) 		//the length of two points in shape A
{
	double x=ax[a]-ax[b],y=ay[a]-ay[b];
	return sqrt(x*x+y*y);
}

double length2(int a,int b) 		//the length of two points in shape B
{
	double x=bx[a]-bx[b],y=by[a]-by[b];
	return sqrt(x*x+y*y);
}

double degree(double a,double b,double c)	//calculate degree
{
	double cs=(a*a+b*b-c*c)/a*b*2.0;//The Law of Cosines
	return acos(cs);
}

int judge1(int a,int b,int c,int d)//judge if the difference of length is too large
{
	double s1=length1(a,b);
	double s2=length2(c,d);
	double stand=s1;
	if(s2>s1)	stand=s2;
	if(abs(s1-s2)/stand>L)	return 0;
	return 1;
}

int judge2(int a1,int b1,int c1,int a2,int b2,int c2)//judge if the difference of length is too large
{
	double s1,s2,s3,deg1,deg2;
	s1=length1(a1,b1);
	s2=length1(b1,c1);
	s3=length1(a1,c1);
	deg1=degree(s1,s2,s3);
	s1=length2(a2,b2);
	s2=length2(b2,c2);
	s3=length2(a2,c2);
	deg2=degree(s1,s2,s3);
	if(abs(deg1-deg2)>pi/18.0)	return 0;
	return 1;
}

void vote(int x,int y)
{
//	printf("%d %d %d\n",tot,x,y);	//show out the voting process
	/*
	I need two 2-dimension arrays to record the voting precess
	array "voting" is to record the total number
	array "add"	   is to record how many should it add in this path
	the way to calculate will be showed more concrete in the report
	*/
	add[x][y]++;
	for(int i=x+1;i<=n;i++)
	{
		for(int j=y+1;j<=m;j++)
		{
			if(!tot)		//when tot==0, means now is searching the first point. So no need to judge.
			{
				tt[++tot].A=i;
				tt[tot].B=j;
				vote(i,j);
				add[x][y]+=add[i][j];//while jump out from the deeper vote,we should first recover and handle the massage
				add[i][j]=0;
				tot--;
			}
			else if(tot==1)		//when tot=1, means searching the second point. So just judge the length.
			{
				if(judge1(x,i,y,j))
				{
					tt[++tot].A=i;
					tt[tot].B=j;
					vote(i,j);
					add[x][y]+=add[i][j];// the same as condition 1
					add[i][j]=0;
					tot--;
				}
			}
			
			else//judge the length and angle
			{
				if(judge1(x,i,y,j)&&judge1(tt[tot-1].A,i,tt[tot-1].B,j)&&judge2(tt[tot-1].A,x,i,tt[tot-1].B,y,j))
				{
					tt[++tot].A=i;
					tt[tot].B=j;
					vote(i,j);
					add[x][y]+=add[i][j];	//the same as condition above
					add[i][j]=0;
					tot--;
				}
			}
		}
	}
	voting[x][y]+=add[x][y];
}

int main()
{
	scanf("%d%d",&n,&m);	//  n  <  m
	
	for(int i=1;i<=n;i++)
		scanf("%lf%lf",&ax[i],&ay[i]);
	for(int i=1;i<=m;i++)
		scanf("%lf%lf",&bx[i],&by[i]);
	//above is normal input.
	
	tot=0;
	tt[tot].A=0;tt[tot].B=0;
	vote(0,0);	//now start to build the tree, also start the voting process.
	
//	printf("**********the result of voting\n");
//	for(int i=1;i<=n;i++)						//show out the result of voting
//	{											//this invalid part is useful while debugging
//		for(int j=1;j<=m;j++)
//		{
//			printf("%d ",voting[i][j]);
//		}
//		printf("\n");
//	}
//	printf("************the real output\n");
	
	for(int i=1;i<=n;i++)
	{
		int maxi=0,maxx=0;
		for(int j=1;j<=m;j++)	//find the max in row i
		{
			if(!chosenline[j]&&voting[i][j]>maxx)
			{
				//printf("%d&&&%d\n",i,j);		//for debugging
				maxi=j;
				maxx=voting[i][j];
			}
		}
		
		if(maxx==1)	continue;
		//maxx==1  indicate the this point can't find a partner
		int flag=1;
		for(int j=1;j<=n;j++)// check if it is the max in column maxi
		{
			if(voting[j][maxi]>maxx)//illegal
			{
				//printf("%d **** %d\n",i,maxi);	//for debugging
				flag=0;
				break;
			}
		}
		if(flag)//if the pair is legal, output it
		{
			printf("(%d, %d)\n",i,maxi);
			chosenline[maxi]=1;	// column maxi can't be chosen again
		}
	}
	return 0;
}
