#include<stdio.h>
#define N 105
int matrix[N][N],sum[N][N];

//use a function to calculate the summary of the area from (ai,aj) to (bi,bj)
int val(int ai,int aj,int bi,int bj)	
{
	return sum[bi][bj]-sum[ai-1][bj]-sum[bi][aj-1]+sum[ai-1][aj-1];
}

int main()
{
	int n,maxx=0;
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
		scanf("%d",&matrix[i][j]);			// above is the normal input
		sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+matrix[i][j]; 
		//calculate the prefix sum of the matrix
	}
	
	for(int si=1;si<=n;si++)
	for(int sj=1;sj<=n;sj++)
	{
		for(int ei=si;ei<=n;ei++)
		for(int ej=sj;ej<=n;ej++)		//enumerate all posibilities of the start and finish
		{
			int value=val(si,sj,ei,ej); //call the function "val" to get the summary of this area
			if(value>maxx)	maxx=value;//if the summary is bigger than max, change the value of max
		}
	}
	
	printf("%d",maxx);
	return 0; 
}
