#include<stdio.h>
#define N 105

int matrix[N][N];
int main()
{
	int n,maxx=0;
	//the maximum submatrix sum is 0 if all the integers are negative, so we set max as 0 at first
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		scanf("%d",&matrix[i][j]);	// above is the normal input
		
	for(int si=1;si<=n;si++)
	for(int sj=1;sj<=n;sj++)
	for(int ei=si;ei<=n;ei++)
	for(int ej=sj;ej<=n;ej++)	//enumerate all posibilities of the start and finish
	{
		int sum=0;
		
		for(int i=si;i<=ei;i++)
		for(int j=sj;j<=ej;j++)//calculate the summary of specified start and finish
		{
			sum+=matrix[i][j];
		}
		
		if(sum>maxx)	maxx=sum;//if the summary is bigger than max, change the value of max
	}
	
	printf("%d",maxx);
	return 0;
}
