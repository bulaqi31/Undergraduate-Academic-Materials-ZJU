/*there are a lot of repetition among the three test
  mainly the testing period
  and the core functions are the programmers before
  so many comments are omitted*/
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>
#define N 105
int matrix[N][N],sum[N][N],colsum[N][N];

int val(int ai,int aj,int bi,int bj)	
{
	return sum[bi][bj]-sum[ai-1][bj]-sum[bi][aj-1]+sum[ai-1][aj-1];
}
//above put all functions needed inside this programmer

void O6(int n)	//the O(N^6)
{
	int maxx=0;
		
	for(int si=1;si<=n;si++)
	for(int sj=1;sj<=n;sj++)
	for(int ei=si;ei<=n;ei++)
	for(int ej=sj;ej<=n;ej++)	
	{
		int sum=0;
		
		for(int i=si;i<=ei;i++)
		for(int j=sj;j<=ej;j++)
		{
			sum+=matrix[i][j];
		}
		
		if(sum>maxx)	maxx=sum;
	}
	return ;
}

void O4(int n)	//the O(N^4)
{
	int maxx=0;
	
	for(int si=1;si<=n;si++)
	for(int sj=1;sj<=n;sj++)
	{
		for(int ei=si;ei<=n;ei++)
		for(int ej=sj;ej<=n;ej++)		
		{
			int value=val(si,sj,ei,ej); 
			if(value>maxx)	maxx=value;
		}
	}
	return ;
}

void O3(int n)	//the O(N^3)
{
	int maxx=0;
	for(int i=1;i<=n;i++)
	for(int j=i;j<=n;j++) 
	{
		int sum=0;

		for(int k=1;k<=n;k++)
		{
			sum+=colsum[j][k]-colsum[i-1][k];	
			if(sum>maxx)	maxx=sum;
			if(sum<0)		sum=0;	
		}
	}
}
clock_t start,stop;
double duration;

int M[6]={5,10,30,50,80,100};//refer to data N
int main()
{
	//Now measure the performance of a function O(N^6)
	printf("performance of a function O(N^6)\n");
	for(int i=0;i<6;i++)
	{
		for(int aa=1;aa<=M[i];aa++)
		{
			for(int bb=1;bb<=M[i];bb++)
				matrix[aa][bb]=rand()%200-100;
		}
		//in order to skip input, we give the matrix a random value
		
		int K=1;
		if(i<4)	K=10;if(i<3) K=100;if(i<2)	K=1000;if(!i)	K=10000;
		//for big N in O(N^6),it waste too much time
		start=clock();
		int j=1;
		while(j<=K)
		{
			O6(M[i]);
			j++;
		}
		stop=clock();
		double Ticks=(double)(stop-start);	//record Ticks
		double tot=Ticks/CLK_TCK;			//record total time
		double dura=tot/K;					//record duration
		printf("N:%d	K:%-6d	Ticks:%.2lf		Total time:%.3lf	Duration:%.5lf\n",M[i],K,Ticks,tot,dura);
	}
	printf("\n\n***-------------------***\n");
	//Now measure the performance of a function O(N^6)	
	printf("performance of a function O(N^4)\n");
	memset(matrix,0,sizeof(matrix));		//reset
	
	for(int i=0;i<6;i++)
	{
		for(int aa=1;aa<=M[i];aa++)
		{
			for(int bb=1;bb<=M[i];bb++)
				matrix[aa][bb]=rand()%200-100;
		}
		//in order to skip input, we give the matrix a random value
		
		int K=100;
		if(i<4)	K=1000;if(i<2)	K=100000;
		//for big N in O(N^6),it waste too much time
		start=clock();
		int j=1;
		while(j<=K)
		{
			O4(M[i]);
			j++;
		}
		stop=clock();
		double Ticks=(double)(stop-start);	//record Ticks
		double tot=Ticks/CLK_TCK;			//record total time
		double dura=tot/K;					//record duration
		printf("N:%d	K:%-6d	Ticks:%.2lf		Total time:%.3lf	Duration:%.5lf\n",M[i],K,Ticks,tot,dura);
	}
	
	printf("\n\n***-------------------***\n");
	//Now measure the performance of a function O(N^6)
	printf("performance of a function O(N^3)\n");
	memset(matrix,0,sizeof(matrix));	//reset
	
	for(int i=0;i<6;i++)
	{
		for(int aa=1;aa<=M[i];aa++)
		{
			for(int bb=1;bb<=M[i];bb++)
				matrix[aa][bb]=rand()%200-100;
		}
		//in order to skip input, we give the matrix a random value
		
		int K=1000;
		if(i<4)	K=10000;if(i<2)	K=1000000;
		//for big N in O(N^4),it waste too little time
		start=clock();
		int j=1;
		while(j<=K)
		{
			O3(M[i]);
			j++;
		}
		stop=clock();
		double Ticks=(double)(stop-start);	//record Ticks
		double tot=Ticks/CLK_TCK;			//record total time
		double dura=tot/K;					//record duration
		printf("N:%d	K:%-6d	Ticks:%.2lf		Total time:%.3lf	Duration:%.5lf\n",M[i],K,Ticks,tot,dura);
	}
	return 0;
}
