#include<stdio.h>
#define N 105

int matrix[N][N],colsum[N][N];
//colsum is used to record the prefix sum of each column

int main()
{
	int n,maxx=0;
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
		scanf("%d",&matrix[i][j]);
		colsum[i][j]=colsum[i-1][j]+matrix[i][j];
		// get column j's prefix sum
	}
	
	for(int i=1;i<=n;i++)
	for(int j=i;j<=n;j++) // now we compresses space on the number of rows,and enumerate all of them
	{
		int sum=0;
		// now we have simplified the question into one-dimension
		for(int k=1;k<=n;k++)
		{
			sum+=colsum[j][k]-colsum[i-1][k];	 //colunm k of the subspace is added to sum		
			if(sum>maxx)	maxx=sum;
			if(sum<0)		sum=0;	//if the sum is negative, throw it.
		}
	}
	
	printf("%d",maxx);
	return 0;
}
