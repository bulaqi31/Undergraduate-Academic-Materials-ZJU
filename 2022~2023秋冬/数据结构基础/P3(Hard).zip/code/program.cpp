/* ��һ���������·��ɾ��
	�ڶ����� ö��i��j�� ���� 1 to i , i to j , j to n���·֮��
	�������ǲ���BFSӲ��
*/ 
// there are many invalid codes used to debug	 
#include<stdio.h>
#include<string.h>
#define NODE 5050
#define EDGE 200010

int n,m;
int tot=0,cnt=0,ans;	// ans is the length of the path
int addval;// the edge the will be deleted
int head[NODE],Fpath[NODE],dis[NODE],known[NODE],pre[NODE],Select[EDGE];
//Fpath[] is used to record the final path
//dis[]	is to record the distance to NO.1
//known[] is to record if it has found a good way
//pre[] is used to record the shortest path
int dis0[NODE],pre0[NODE];

struct edge{
	int from,to,val,nxt;
}e[EDGE];
// create an Adjacency List


void built(int x,int y,int z)
{
	e[++tot].from=x;
	e[tot].to=y;
	e[tot].val=z;
	e[tot].nxt=head[x];
	head[x]=tot;
}
//adding edges

void change(int BreakPNT)// change the infomation of 2nd path
{
	int count[NODE];
	memset(count,0,sizeof(count));
	memset(Fpath,0,sizeof(Fpath));//clear the array Fpath
	cnt=0;
	int nextOne;
	for(int i=m;i;i=nextOne) //we write down the path by tracking back
	{
//		printf("i:%d  cnt:%d count:%d\n",i,cnt,count[i]);
		if(i!=BreakPNT&&count[i])	break;// not BreakPNT and has been through,break at once 
		Fpath[++cnt]=i;
		count[i]++;
		
		if(i==BreakPNT&&count[i]==2)	break;//the situation of a circle
		if(i==BreakPNT&&cnt>1)//the situation of not circle  cnt>1could avoid the situation BreakPNT==m
		{
			int prev=Fpath[cnt-1];
			int Edge=pre[prev];
			if(Edge!=pre0[i]||!Select[Edge])	break;
		}
		
		int num=pre0[i];
		nextOne=e[num].from;
	}
	
	int ddd=e[pre[BreakPNT]].from;
//	printf("%dhahahahaah%d\n",ddd,cnt);
	for(int i=ddd;i;i=nextOne)
	{
		Fpath[++cnt]=i;
		int num=pre[i];
		nextOne=e[num].from;
	}
}

void dij(int x,int y)//dijktsra    we first find the SHTpath
{
	
	for(int i=1;i<=m;i++)
		dis[i]=1e8;
	dis[x]=0,known[x]=1;
	
	while(x!=y)
	{
		
		for(int k=head[x];k;k=e[k].nxt)
		{
			int to=e[k].to,val=e[k].val;
			if(dis[to]>dis[x]+val)
				dis[to]=dis[x]+val,pre[to]=k;
		}
		
		int minn=1e8,chose;
		for(int i=1;i<=m;i++)
		{
			if(!known[i]&&dis[i]<minn)
			{
				minn=dis[i];
				chose=i;				//find the minimum
			}
		}
//		printf("%d %d %d\n",x,dis[2],chose);
		
		x=chose,known[chose]=1;
	}
}

int dij0(int x,int y)
{
	memset(known,0,sizeof(known)); //clear the array known
	memset(pre0,0,sizeof(pre0));	//clear the array pre0
	for(int i=1;i<=m;i++)
		dis0[i]=1e8;
	
	dis0[x]=0;
	int now=x;
	while(!known[y])
	{
		for(int k=head[now];k;k=e[k].nxt)
		{
			int to=e[k].to,val=e[k].val;
//			printf("now:%d    to:%d     %d %d %d\n",now,to,pre[to],known[x],Select[k]);
			// we should let it find another way, so pre[to] can not be k, if it is the first time in x
			if(now!=x&&to!=x)//the edge doesn't include x
			{
				if(dis0[to]>dis0[now]+val) //update the minimum dis0[]
					dis0[to]=dis0[now]+val,pre0[to]=k;
			}
			
			else if(now==x)//now is x
			{
				
				if((known[x]==1||!Select[k])&&(dis0[to]>dis0[now]+val))// we could not walk the SHTpath!
					dis0[to]=dis0[now]+val,pre0[to]=k;
			}
			
			else if(to==x)
			{
				if(!dis0[x])	dis0[x]=dis0[now]+val,pre0[to]=k;
				else if(dis0[to]>dis0[now]+val)  dis0[to]=dis0[now]+val,pre0[to]=k;
			}
		}
		
		int minn=1e8,chose=0;
		for(int i=1;i<=m;i++)
		{
			if((i!=x&&!known[i]&&dis0[i]<minn)||(!known[i]&&dis0[i]&&i==x&&dis0[i]<minn))
			//it is easy while i!=x
			//while i=x, we should make sure it has been went through at least once
			{
				minn=dis0[i];
				chose=i;				//find the minimum
			}
		}
//		for(int i=1;i<=m;i++)
//			printf("%d ",dis0[i]);
//		printf("\nchose:   %d\n",chose);
		if(!chose)	return 0; // no path is found
		
		now=chose,known[chose]++;
		if(dis0[now]+dis[x]>=ans) return 0;// in this situation it is impossible to be 2nd SHTpath		
	}
	
	return dis0[y];
}


int main()
{
	pre[0]=m;
	scanf("%d%d",&m,&n);
	
	for(int i=1;i<=n;i++)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		built(x,y,z);
		//built(y,x,z);
	}
	
	dij(1,m);	//calculate the shortest and record the path
	
	ans=1e8;
//	printf("************\n");
//	for(int i=m;i;i=e[pre[i]].from)
//		printf("%d\n",i);
//	printf("************\n");
	for(int i=m;i;i=e[pre[i]].from)//enumerate all edges and try to find another path to replace it
	{	
//		printf("&&&&&&&&&&&%d\n",i);
		Select[pre[i]]=1;
		addval=dij0(i,m);// another path
		
		int Now=addval+dis[i];
//		printf("&&&&%d  %d&&&\n",addval,Now);
		if(addval&&Now>dis[m])	//the 2nd path must not longer than SHT, but we should make sure not equal
		{
//			printf("***********%d*****\n",i);
			change(i);
			ans=Now;
		}
//		printf("%d\n",addval);
	}
	
//	printf("%d\n",cnt);
	if(!cnt)// there is no 2nd shortest path
	{
		printf("No 2nd SHTpath!");
		return 0;
	}
	printf("%d",ans);
	for(int i=0;i<cnt;i++)
	{
		printf(" %d",Fpath[cnt-i]);//output
	}
	//printf("%d",dis[m]);
	return 0;
}
